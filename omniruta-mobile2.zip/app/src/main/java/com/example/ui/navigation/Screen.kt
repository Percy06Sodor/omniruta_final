package com.example.ui.navigation

sealed class Screen(val route: String) {
    object Login : Screen("login")
    object Register : Screen("register")
    object EmployeeHome : Screen("employee_home")
    object DriverHome : Screen("driver_home")
    object ReportItem : Screen("report_item")
}
