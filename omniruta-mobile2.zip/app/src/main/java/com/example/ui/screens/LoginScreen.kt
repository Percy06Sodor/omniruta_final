package com.example.ui.screens

import android.app.Activity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.firebase.auth.GoogleAuthProvider
import androidx.compose.ui.platform.LocalContext
import com.example.R
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

@Composable
fun LoginScreen(
    onNavigateToRegister: () -> Unit,
    onLoginEmployee: () -> Unit,
    onLoginDriver: () -> Unit
) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }
    
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf("") }
    
    val context = LocalContext.current
    
    LaunchedEffect(Unit) {
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(context.getString(R.string.default_web_client_id))
            .requestEmail()
            .build()
        GoogleSignIn.getClient(context, gso).signOut()
    }
    
    val googleSignInLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val task = GoogleSignIn.getSignedInAccountFromIntent(result.data)
            try {
                val account = task.getResult(ApiException::class.java)
                val idToken = account.idToken
                if (idToken == null) {
                    isLoading = false
                    errorMessage = "Error: ID Token nulo. Verifica el SHA-1 en Firebase."
                    return@rememberLauncherForActivityResult
                }
                val credential = GoogleAuthProvider.getCredential(idToken, null)
                FirebaseAuth.getInstance().signInWithCredential(credential)
                    .addOnCompleteListener { authTask ->
                        if (authTask.isSuccessful) {
                            val user = authTask.result?.user
                            if (user != null) {
                                FirebaseFirestore.getInstance().collection("users")
                                    .document(user.uid)
                                    .get()
                                    .addOnCompleteListener { firestoreTask ->
                                        isLoading = false
                                        if (firestoreTask.isSuccessful) {
                                            val document = firestoreTask.result
                                            if (document != null && document.exists()) {
                                                val role = document.getString("role") ?: "EMPLOYEE"
                                                if (role == "DRIVER") {
                                                    onLoginDriver()
                                                } else {
                                                    onLoginEmployee()
                                                }
                                            } else {
                                                // Default new user to EMPLOYEE
                                                isLoading = true
                                                val userProfile = hashMapOf(
                                                    "email" to (user.email ?: ""),
                                                    "role" to "EMPLOYEE",
                                                    "name" to (user.displayName ?: "Usuario")
                                                )
                                                FirebaseFirestore.getInstance().collection("users")
                                                    .document(user.uid)
                                                    .set(userProfile)
                                                isLoading = false
                                                onLoginEmployee()
                                            }
                                        } else {
                                            errorMessage = "Error: ${firestoreTask.exception?.localizedMessage}"
                                            FirebaseAuth.getInstance().signOut()
                                        }
                                    }
                            } else {
                                isLoading = false
                                errorMessage = "Error al obtener datos del usuario."
                            }
                        } else {
                            isLoading = false
                            errorMessage = authTask.exception?.localizedMessage ?: "Error al autenticar con Google."
                        }
                    }
            } catch (e: ApiException) {
                isLoading = false
                errorMessage = "Google Sign-In falló (código ${e.statusCode}). Verifica SHA-1."
            } catch (e: Exception) {
                isLoading = false
                errorMessage = "Error: ${e.localizedMessage}"
            }
        } else {
            isLoading = false
            errorMessage = "Inicio de sesión cancelado o fallido (código: ${result.resultCode})"
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(24.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Spacer(modifier = Modifier.height(32.dp))
        
        Text("OmniRuta", fontSize = 36.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, letterSpacing = (-1).sp)
        Spacer(modifier = Modifier.height(8.dp))
        Text("Bienvenido de nuevo", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        
        Spacer(modifier = Modifier.height(32.dp))
        
        if (errorMessage.isNotEmpty()) {
            Text(
                text = errorMessage,
                color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(bottom = 16.dp)
            )
        }
        
        OutlinedTextField(
            value = email,
            onValueChange = { email = it; errorMessage = "" },
            label = { Text("Correo Electrónico") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
                unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant,
                focusedBorderColor = MaterialTheme.colorScheme.primary
            ),
            enabled = !isLoading
        )
        
        Spacer(modifier = Modifier.height(16.dp))
        
        OutlinedTextField(
            value = password,
            onValueChange = { password = it; errorMessage = "" },
            label = { Text("Contraseña") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            shape = RoundedCornerShape(16.dp),
            visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
            trailingIcon = {
                val image = if (passwordVisible) Icons.Filled.Visibility else Icons.Filled.VisibilityOff
                IconButton(onClick = { passwordVisible = !passwordVisible }) {
                    Icon(imageVector = image, contentDescription = if (passwordVisible) "Ocultar" else "Mostrar")
                }
            },
            colors = OutlinedTextFieldDefaults.colors(
                unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant,
                focusedBorderColor = MaterialTheme.colorScheme.primary
            ),
            enabled = !isLoading
        )
        
        Spacer(modifier = Modifier.height(32.dp))
        
        if (isLoading) {
            CircularProgressIndicator()
        } else {
            Button(
                onClick = {
                    if (email.isBlank() || password.isBlank()) {
                        errorMessage = "Por favor, ingresa tu correo electrónico y contraseña."
                        return@Button
                    }
                    
                    isLoading = true
                    FirebaseAuth.getInstance().signInWithEmailAndPassword(email.trim(), password)
                        .addOnCompleteListener { task ->
                            if (task.isSuccessful) {
                                val user = task.result?.user
                                if (user != null) {
                                    // Fetch user role from Firestore
                                    FirebaseFirestore.getInstance().collection("users")
                                        .document(user.uid)
                                        .get()
                                        .addOnCompleteListener { firestoreTask ->
                                            isLoading = false
                                            if (firestoreTask.isSuccessful) {
                                                val document = firestoreTask.result
                                                if (document != null && document.exists()) {
                                                    val role = document.getString("role") ?: "EMPLOYEE"
                                                    if (role == "DRIVER") {
                                                        onLoginDriver()
                                                    } else {
                                                        onLoginEmployee()
                                                    }
                                                } else {
                                                    // Fallback/Default if no role is recorded
                                                    errorMessage = "Perfil de usuario no encontrado en la base de datos."
                                                    FirebaseAuth.getInstance().signOut()
                                                }
                                            } else {
                                                errorMessage = "Error al obtener rol: ${firestoreTask.exception?.localizedMessage}"
                                                FirebaseAuth.getInstance().signOut()
                                            }
                                        }
                                } else {
                                    isLoading = false
                                    errorMessage = "Error al autenticar."
                                }
                            } else {
                                isLoading = false
                                errorMessage = task.exception?.localizedMessage ?: "Error al iniciar sesión."
                            }
                        }
                },
                modifier = Modifier.fillMaxWidth().height(56.dp),
                shape = RoundedCornerShape(16.dp)
            ) {
                Text("Iniciar Sesión", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        
        OutlinedButton(
            onClick = {
                try {
                    isLoading = true
                    val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                        .requestIdToken(context.getString(R.string.default_web_client_id))
                        .requestEmail()
                        .build()
                    val googleSignInClient = GoogleSignIn.getClient(context, gso)
                    googleSignInLauncher.launch(googleSignInClient.signInIntent)
                } catch (e: Exception) {
                    isLoading = false
                    errorMessage = "Error al iniciar Google Sign-In. Prueba en un dispositivo físico. Detalles: ${e.localizedMessage}"
                }
            },
            modifier = Modifier.fillMaxWidth().height(56.dp),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.outlinedButtonColors(
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MaterialTheme.colorScheme.onSurfaceVariant
            ),
            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            enabled = !isLoading
        ) {
            Text("Continuar con Google", fontWeight = FontWeight.SemiBold) // Normally would have a Google Icon
        }
        
        Spacer(modifier = Modifier.height(32.dp))
        
        TextButton(onClick = onNavigateToRegister, enabled = !isLoading) {
            Text("¿No tienes cuenta? Regístrate aquí", fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
