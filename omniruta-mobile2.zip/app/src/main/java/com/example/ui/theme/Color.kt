package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val SleekPrimary = Color(0xFF0056D2)
val SleekBackground = Color(0xFFF8F9FF)
val SleekSurface = Color(0xFFFFFFFF)
val SleekSurfaceVariant = Color(0xFFF1F5F9) // slate-100
val SleekSurfaceVariantDark = Color(0xFFE2E8F0) // slate-200
val SleekOnBackground = Color(0xFF0F172A) // slate-900
val SleekOnSurface = Color(0xFF0F172A)
val SleekOnSurfaceVariant = Color(0xFF64748B) // slate-500
val SleekOutline = Color(0xFFF1F5F9) // slate-100
val SleekOutlineVariant = Color(0xFFE2E8F0) // slate-200
val SleekBlue50 = Color(0xFFEFF6FF)
val SleekBlue100 = Color(0xFFDBEAFE)
val SleekBlue900 = Color(0xFF1E3A8A)
