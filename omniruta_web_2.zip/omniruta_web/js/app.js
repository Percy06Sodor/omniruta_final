import { initializeApp } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-app.js";
import { 
  getFirestore, 
  collection, 
  addDoc, 
  onSnapshot, 
  query, 
  orderBy 
} from "https://www.gstatic.com/firebasejs/10.8.0/firebase-firestore.js";
import { 
  getAuth, 
  onAuthStateChanged, 
  signOut 
} from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";

const firebaseConfig = {
  apiKey: "AIzaSyDGNMhL70eJ2fvZVhlvFKC9AaXea9nzlHc",
  authDomain: "omniruta-49a33.firebaseapp.com",
  projectId: "omniruta-49a33",
  storageBucket: "omniruta-49a33.firebasestorage.app",
  messagingSenderId: "758755740384",
  appId: "1:758755740384:web:064b221cec7918ee5fde85",
  measurementId: "G-MTYZK84YYW"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const auth = getAuth(app);

const userNombreSpan = document.getElementById('userNombre');

onAuthStateChanged(auth, (user) => {
  if (user) {
    if (!user.email.endsWith('@admin.com')) {
      signOut(auth);
      window.location.href = "login.html";
      return;
    }

    if (userNombreSpan) {
      userNombreSpan.innerText = user.displayName || user.email.split('@')[0];
    }
  } else {
    window.location.href = "login.html";
  }
});

const cerrarSesion = document.getElementById('btnCerrarSesion');
if (cerrarSesion) {
  cerrarSesion.addEventListener('click', async (e) => {
    e.preventDefault();
    try {
      await signOut(auth);
      window.location.href = "login.html";
    } catch (error) {
      console.error("Error al cerrar sesión:", error);
      alert("Hubo un problema al cerrar la sesión");
    }
  });
}

const fleteForm = document.getElementById('fleteForm');

if (fleteForm) {
  fleteForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const user = auth.currentUser;
    if (!user) {
      alert("Debes estar autenticado para realizar un envío.");
      return;
    }

    const btnGuardar = document.getElementById('btnGuardar');
    btnGuardar.disabled = true;
    btnGuardar.innerText = "Guardando...";

    try {
      const idRandom = "#ENV-" + Math.floor(1000 + Math.random() * 9000);
      const origen = document.getElementById('origen').value;
      const destino = document.getElementById('destino').value;
      const tamano = document.getElementById('tamano').value;
      const fecha = document.getElementById('fechaEnvio').value;

      await addDoc(collection(db, "solicitudesFlete"), {
        idFlete: idRandom,
        sucursalOrigen: origen,
        sucursalDestino: destino,
        tamanoCarga: tamano,
        fechaEnvio: fecha,
        estado: "Pendiente",
        creadoEl: new Date().toISOString(),
        creadoPor: user.email 
      });

      fleteForm.reset();
    } catch (error) {
      console.error("Error al guardar en Firestore:", error);
      alert("Hubo un error al crear la solicitud.");
    } finally {
      btnGuardar.disabled = false;
      btnGuardar.innerText = "Solicitar Envío";
    }
  });
}

const q = query(collection(db, "solicitudesFlete"), orderBy("creadoEl", "desc"));

onSnapshot(q, (snapshot) => {
  const tbody = document.getElementById('tablaFletes');
  if (!tbody) return;

  tbody.innerHTML = '';

  if (snapshot.empty) {
    tbody.innerHTML = `
      <tr>
        <td colspan="6" class="text-center py-4 text-muted">No hay solicitudes registradas aún.</td>
      </tr>`;
    return;
  }

  snapshot.forEach(doc => {
    const data = doc.data();

    let badgeClass = 'badge-pendiente';
    if (data.estado === 'En Viaje') badgeClass = 'badge-en-viaje';
    if (data.estado === 'Entregado') badgeClass = 'badge-entregado';

    tbody.innerHTML += `
      <tr>
        <td class="fw-bold">${data.idFlete || '#1050'}</td>
        <td>${data.sucursalOrigen}</td>
        <td>${data.sucursalDestino}</td>
        <td>${data.fechaEnvio}</td>
        <td><span class="badge ${badgeClass} px-3 py-2 rounded-pill fw-semibold">${data.estado}</span></td>
        <td>
          <button class="btn btn-sm btn-light border p-1" title="Ver detalle">
            <img src="../img/informacion.png" alt="Ver" width="16" height="16">
          </button>
        </td>
      </tr>
    `;
  });
});