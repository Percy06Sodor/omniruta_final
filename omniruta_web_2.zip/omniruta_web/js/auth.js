import { initializeApp } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-app.js";
import { 
  getAuth, 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  updateProfile 
} from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";

const firebaseConfig = {
  apiKey: "AIzaSyDGNMhL70eJ2fvZVhlvFKC9AaXea9nzlHc",
  authDomain: "omniruta-49a33.firebaseapp.com",
  projectId: "omniruta-49a33",
  storageBucket: "omniruta-49a33.firebasestorage.app",
  messagingSenderId: "758755740384",
  appId: "1:758755740384:web:064b221cec7918ee5fde85",
  measurementId: "G-MTYZK84YYW"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

let isRegisterMode = false;
const authForm = document.getElementById('authForm');
const nombreGroup = document.getElementById('nombreGroup');
const btnAuth = document.getElementById('btnAuth');
const toggleAuthMode = document.getElementById('toggleAuthMode');
const toggleText = document.getElementById('toggleText');
const alertMsg = document.getElementById('alertMsg');


toggleAuthMode.addEventListener('click', (e) => {
  e.preventDefault();
  isRegisterMode = !isRegisterMode;
  alertMsg.classList.add('d-none');

  if (isRegisterMode) {
    nombreGroup.classList.remove('d-none');
    btnAuth.innerText = "Registrar Administrador";
    toggleText.innerText = "¿Ya tienes cuenta?";
    toggleAuthMode.innerText = "Iniciar Sesión";
  } else {
    nombreGroup.classList.add('d-none');
    btnAuth.innerText = "Iniciar Sesión";
    toggleText.innerText = "¿No tienes cuenta de administrador?";
    toggleAuthMode.innerText = "Registrarse";
  }
});

authForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  alertMsg.classList.add('d-none');

  const email = document.getElementById('emailAdmin').value.trim();
  const password = document.getElementById('passwordAdmin').value;
  const nombre = document.getElementById('nombreAdmin').value.trim();
  if (!email.endsWith('@admin.com')) {
    mostrarError("Acceso denegado: Solo se permiten correos con dominio @admin.com");
    return;
  }

  btnAuth.disabled = true;

  try {
    if (isRegisterMode) {
      if (!nombre) {
        mostrarError("Por favor, ingresa tu nombre completo.");
        btnAuth.disabled = false;
        return;
      }
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      await updateProfile(userCredential.user, { displayName: nombre });

      window.location.href = "solicitar_envio.html";
    } else {
      await signInWithEmailAndPassword(auth, email, password);
      window.location.href = "solicitar_envio.html";
    }
  } catch (error) {
    console.error("Error Auth:", error.code);
    if (error.code === 'auth/invalid-credential' || error.code === 'auth/user-not-found') {
      mostrarError("Correo o contraseña incorrectos.");
    } else if (error.code === 'auth/email-already-in-use') {
      mostrarError("Este correo ya está registrado.");
    } else if (error.code === 'auth/weak-password') {
      mostrarError("La contraseña debe tener al menos 6 caracteres.");
    } else {
      mostrarError("Error al autenticar: " + error.message);
    }
  } finally {
    btnAuth.disabled = false;
  }
});

function mostrarError(mensaje) {
  alertMsg.innerText = mensaje;
  alertMsg.classList.remove('d-none');
}