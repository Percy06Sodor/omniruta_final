import { initializeApp } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-app.js";
import { 
  getFirestore, 
  collection, 
  onSnapshot, 
  query, 
  where 
} from "https://www.gstatic.com/firebasejs/10.8.0/firebase-firestore.js";
import { 
  getAuth, 
  onAuthStateChanged, 
  signOut 
} from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";

const firebaseConfig = {
  apiKey: "AIzaSyDGNMhL70eJ2fvZVhlvFKC9AaXea9nzlHc",
  authDomain: "omniruta-49a33.firebaseapp.com",
  projectId: "omniruta-49a33",
  storageBucket: "omniruta-49a33.firebasestorage.app",
  messagingSenderId: "758755740384",
  appId: "1:758755740384:web:064b221cec7918ee5fde85",
  measurementId: "G-MTYZK84YYW"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const auth = getAuth(app);

const userNombreSpan = document.getElementById('userNombre');

onAuthStateChanged(auth, (user) => {
  if (user) {
    if (!user.email.endsWith('@admin.com')) {
      signOut(auth);
      window.location.href = "login.html";
      return;
    }
    
    if (userNombreSpan) {
      userNombreSpan.innerText = user.displayName || user.email.split('@')[0];
    }

    cargarMisEnvios(user.email);

  } else {
    window.location.href = "login.html";
  }
});

const btnCerrarSesion = document.getElementById('btnCerrarSesion');
if (btnCerrarSesion) {
  btnCerrarSesion.addEventListener('click', async (e) => {
    e.preventDefault();
    await signOut(auth);
    window.location.href = "login.html";
  });
}

function cargarMisEnvios(userEmail) {
  const q = query(
    collection(db, "solicitudesFlete"),
    where("creadoPor", "==", userEmail)
  );

  onSnapshot(q, (snapshot) => {
    const tbody = document.getElementById('tablaMisEnvios');
    if (!tbody) return;

    tbody.innerHTML = '';

    if (snapshot.empty) {
      tbody.innerHTML = `
        <tr>
          <td colspan="5" class="text-center py-4 text-muted">
            No has registrado ningún envío aún.
          </td>
        </tr>`;
      return;
    }

    snapshot.forEach(docSnap => {
      const data = docSnap.data();

      let badgeClass = 'badge-pendiente';
      if (data.estado === 'En Viaje') badgeClass = 'bg-primary text-white';
      if (data.estado === 'Entregado') badgeClass = 'badge-entregado';

      tbody.innerHTML += `
        <tr>
          <td class="fw-bold">${data.idFlete || '#' + docSnap.id.substring(0, 5)}</td>
          <td>${data.sucursalOrigen} ➔ ${data.sucursalDestino}</td>
          <td>${data.tamanoCarga || 'Mediano'}</td>
          <td>${data.fechaEnvio || 'N/A'}</td>
          <td><span class="badge ${badgeClass} px-3 py-2 rounded-pill fw-semibold">${data.estado || 'Pendiente'}</span></td>
        </tr>
      `;
    });
  }, (error) => {
    console.error("Error al cargar envíos:", error);
  });
}