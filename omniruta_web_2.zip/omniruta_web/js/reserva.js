import { initializeApp } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-app.js";
import { 
  getFirestore, 
  collection, 
  onSnapshot, 
  query, 
  orderBy,
  doc,
  updateDoc 
} from "https://www.gstatic.com/firebasejs/10.8.0/firebase-firestore.js";
import { 
  getAuth, 
  onAuthStateChanged, 
  signOut 
} from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";

const firebaseConfig = {
  apiKey: "AIzaSyDGNMhL70eJ2fvZVhlvFKC9AaXea9nzlHc",
  authDomain: "omniruta-49a33.firebaseapp.com",
  projectId: "omniruta-49a33",
  storageBucket: "omniruta-49a33.firebasestorage.app",
  messagingSenderId: "758755740384",
  appId: "1:758755740384:web:064b221cec7918ee5fde85",
  measurementId: "G-MTYZK84YYW"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const auth = getAuth(app);

const userNombreSpan = document.getElementById('userNombre');

onAuthStateChanged(auth, (user) => {
  if (user) {
    if (!user.email.endsWith('@admin.com')) {
      signOut(auth);
      window.location.href = "login.html";
      return;
    }
    if (userNombreSpan) {
      userNombreSpan.innerText = user.displayName || user.email.split('@')[0];
    }
  } else {
    window.location.href = "login.html";
  }
});

const btnCerrarSesion = document.getElementById('btnCerrarSesion');
if (btnCerrarSesion) {
  btnCerrarSesion.addEventListener('click', async (e) => {
    e.preventDefault();
    await signOut(auth);
    window.location.href = "login.html";
  });
}

const q = query(collection(db, "reservas"), orderBy("creadoEl", "desc"));

onSnapshot(q, (snapshot) => {
  const tbody = document.getElementById('tablaReservasMobile');
  if (!tbody) return;

  tbody.innerHTML = '';

  if (snapshot.empty) {
    tbody.innerHTML = `
      <tr>
        <td colspan="7" class="text-center py-4 text-muted">Aún no hay reservas realizadas desde la app móvil.</td>
      </tr>`;
    return;
  }

  snapshot.forEach(docSnap => {
    const data = docSnap.data();
    const docId = docSnap.id;

    let badgeClass = 'badge-pendiente';
    if (data.estado === 'Confirmada') badgeClass = 'badge-entregado';
    if (data.estado === 'Cancelada') badgeClass = 'bg-danger text-white';

    tbody.innerHTML += `
      <tr>
        <td class="fw-bold">${data.idReserva || '#' + docId.substring(0, 5)}</td>
        <td>
          <div class="fw-semibold">${data.pasajero || 'Usuario App'}</div>
          <small class="text-muted">${data.emailUsuario || 'Sin correo'}</small>
        </td>
        <td>${data.origen} ➔ ${data.destino}</td>
        <td>${data.fechaViaje}</td>
        <td class="text-center"><span class="badge bg-secondary px-2 py-1">${data.asientos || 1}</span></td>
        <td><span class="badge ${badgeClass} px-3 py-2 rounded-pill fw-semibold">${data.estado || 'Pendiente'}</span></td>
        <td class="text-center">
          <button class="btn btn-sm btn-outline-success me-1" onclick="cambiarEstadoReserva('${docId}', 'Confirmada')" title="Confirmar">
            ✓
          </button>
          <button class="btn btn-sm btn-outline-danger" onclick="cambiarEstadoReserva('${docId}', 'Cancelada')" title="Cancelar">
            ✕
          </button>
        </td>
      </tr>
    `;
  });
});

window.cambiarEstadoReserva = async (docId, nuevoEstado) => {
  try {
    const reservaRef = doc(db, "reservas", docId);
    await updateDoc(reservaRef, { estado: nuevoEstado });
  } catch (error) {
    console.error("Error al actualizar la reserva:", error);
    alert("No se pudo actualizar el estado de la reserva.");
  }
};